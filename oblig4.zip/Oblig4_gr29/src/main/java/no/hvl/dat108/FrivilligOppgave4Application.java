package no.hvl.dat108;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrivilligOppgave4Application {

	public static void main(String[] args) {
		SpringApplication.run(FrivilligOppgave4Application.class, args);
	}

}
