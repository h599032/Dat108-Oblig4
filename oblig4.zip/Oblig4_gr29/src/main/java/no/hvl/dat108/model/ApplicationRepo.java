//package no.hvl.dat108.model;
//
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface ApplicationRepo extends JpaRepository<Application,Integer> {
//	Application findByName(String name);
//}
